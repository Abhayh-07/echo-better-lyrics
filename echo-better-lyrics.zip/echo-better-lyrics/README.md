# Better Lyrics for Echo (lyrics extension)

Word/syllable-synced lyrics for Echo (brahmkshatriya/echo) from the Better Lyrics API
(api.betterlyrics.org) and the Unison community database (unison.boidu.dev). Falls back to
line-synced (TTML line timing or LRC), then plain text. Order of results: word > line > plain.

STATUS: source and tests are written but NOT compiled or run here (no Kotlin/Gradle/Android SDK/network
in the authoring sandbox). A Java port of the parser core passed all its fixtures; that validates the
algorithm, not the Kotlin.

## Files
- gradle.properties                      (extType=lyrics, extId=better_lyrics, extClass=BetterLyricsExtension)
- ext/src/main/java/dev/brahmkshatriya/echo/extension/
  - BetterLyricsExtension.kt             LyricsClient implementation
  - TrackMapping.kt, LyricsMapping.kt    only files that touch Echo model classes
  - core/ Model, TtmlParser, TtmlConverter, LrcParser, Http, BetterLyricsApi, UnisonApi, Sources, LyricsResolver
- ext/src/test/.../ExtensionUnitTest.kt  (replaces the template's), core/*Test.kt

## Build with GitHub Actions (phone-friendly)
1. Create a **public GitHub repository** and tick **Add a README**.
2. Upload `echo-better-lyrics.zip` to the repository root.
3. Create `.github/workflows/build-apk.yml` and paste the workflow file supplied with this project.
4. Open **Actions**, select the latest run, and wait for the build.
5. Download the `better-lyrics-extension` artifact. It contains `better_lyrics.apk` and `better_lyrics.eapk`.

The workflow clones the official Echo extension template, overlays this source, adds the required dependencies, and attempts a debug build. It also runs unit tests and uploads logs. **This project has not been compiled in the authoring environment**, so a first-run compiler/API failure is still possible.

For a local build, use the official template and follow the same overlay process in `ci/build.sh`.

## Install on Android
1. Copy the APK to the phone and open it (allow "install unknown apps"), or import it from Echo's extensions screen.
2. In Echo, open extension management, enable "Better Lyrics" under lyrics, and move it up in priority.
3. Play a song and open lyrics. Menu names may differ by Echo version.

## Test procedure
1. Pick a song: the docs' own example is "E85" by Don Toliver, album OCTANE, 154 s. Check it is cached:
   curl -i "https://api.betterlyrics.org/getLyrics?s=E85&a=Don%20Toliver&al=OCTANE&d=154"
   Expect 200 with a "ttml" field full of <span begin=...>. A 401 means not cached (no key); try another song.
2. ECHO_BL_LIVE=1 ./gradlew :ext:test --tests '*LiveBetterLyricsTest'
3. On device: play the song, open lyrics, confirm the highlight moves word by word and stays in time.
   If it only moves line by line, see Limitations.

## Verified vs. not verified
Verified from Echo's published API docs: LyricsClient (searchTrackLyrics/loadLyrics), Lyrics.WordByWord/Timed/Simple,
Lyrics.Item(text,startTime,endTime), Feed.toFeed, Track.duration is ms, manifest keys, gradle.properties keys.
NOT verified (fix on first compile/run):
- Artist.name and Album.title (TrackMapping.kt)
- Unit of Lyrics.Item times; assumed ms (ECHO_TIME_SCALE in LyricsMapping.kt)
- Whether Echo's lyrics screen actually highlights per word, and whether it wants trailing spaces (KEEP_TRAILING_SPACES)
- ext/build.gradle.kts contents, OkHttp 4+, coroutines and JUnit on the ext classpath
- Echo's README says the app is moving to a Compose rewrite, so the extension API may change.

## Limitations
- No API key: Better Lyrics only serves already-cached songs without one (keys are not being issued, and the
  maintainer says the extension's key is not for other projects). Uncached songs fall through to Unison.
- Unison lookup is by title/artist/album/duration; video-id lookup is not used because Echo's track id is not
  necessarily a YouTube id.
- Duets/agents, transliteration and translation are parsed but cannot be passed through Echo's Lyrics model.
- Background vocals become their own line after the lead line.
- Lyrics that end >15 s after the track's duration are rejected as a different recording.
