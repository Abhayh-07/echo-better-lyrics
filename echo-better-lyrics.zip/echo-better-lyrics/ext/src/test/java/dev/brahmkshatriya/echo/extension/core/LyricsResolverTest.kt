package dev.brahmkshatriya.echo.extension.core

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LyricsResolverTest {
    private val query = TrackQuery("Song", "Artist", "Artist", "Album", 200_000)

    private fun resolved(source: String, body: LyricsBody) = ResolvedLyrics(source, body, null, null)
    private val words = LyricsBody.Words(listOf(listOf(WordItem("a", 0, 1))))
    private val lines = LyricsBody.Lines(listOf(LineItem("a", 0, 1)))
    private val plain = LyricsBody.Plain("a")

    private class Fake(
        override val name: String,
        private val result: ResolvedLyrics?,
        private val fail: Boolean = false,
    ) : LyricsSource {
        var calls = 0
        override suspend fun fetch(query: TrackQuery): ResolvedLyrics? {
            calls++
            if (fail) throw IllegalStateException("boom")
            return result
        }
    }

    @Test
    fun mostPreciseSyncComesFirst() = runBlocking {
        val r = LyricsResolver(
            listOf(Fake("A", resolved("A", plain)), Fake("B", resolved("B", lines)), Fake("C", resolved("C", words))),
        ).resolve(query)
        assertEquals(listOf("C", "B", "A"), r.map { it.source })
    }

    @Test
    fun aFailingSourceDoesNotHideAnother() = runBlocking {
        val r = LyricsResolver(listOf(Fake("A", null, fail = true), Fake("B", resolved("B", lines)))).resolve(query)
        assertEquals(listOf("B"), r.map { it.source })
    }

    @Test
    fun nothingFoundIsAnEmptyListNotAnError() = runBlocking {
        assertTrue(LyricsResolver(listOf(Fake("A", null), Fake("B", null, fail = true))).resolve(query).isEmpty())
    }

    @Test
    fun successfulLookupsAreCachedButMissesAreRetried() = runBlocking {
        val hit = Fake("A", resolved("A", words))
        val miss = Fake("B", null)
        val resolver = LyricsResolver(listOf(hit, miss))
        resolver.resolve(query)
        resolver.resolve(query)
        assertEquals(1, hit.calls)

        val onlyMiss = Fake("C", null)
        val r2 = LyricsResolver(listOf(onlyMiss))
        r2.resolve(query)
        r2.resolve(query)
        assertEquals(2, onlyMiss.calls)
    }

    @Test
    fun expiredCacheEntriesAreDropped() {
        var t = 0L
        val cache = TtlCache<String, String>(2, 1_000L) { t }
        cache.put("k", "v")
        assertEquals("v", cache.get("k"))
        t = 1_000L
        assertEquals(null, cache.get("k"))
    }
}
