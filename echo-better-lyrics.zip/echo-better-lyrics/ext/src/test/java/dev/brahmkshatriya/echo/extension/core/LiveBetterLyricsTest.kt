package dev.brahmkshatriya.echo.extension.core

import okhttp3.OkHttpClient
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.Test

/**
 * Hits the real service. Skipped unless ECHO_BL_LIVE=1, so normal builds stay offline.
 * The track below is the example used in the official docs (https://docs.betterlyrics.org/reference/get-lyrics);
 * the service only answers uncached songs for key holders, so confirm with curl first (see README).
 */
class LiveBetterLyricsTest {
    @Test
    fun knownSongReturnsWordSyncedLyrics() {
        assumeTrue("set ECHO_BL_LIVE=1 to run", System.getenv("ECHO_BL_LIVE") == "1")
        runBlocking {
            val q = TrackQuery("E85", "Don Toliver", "Don Toliver", "OCTANE", 154_000)
            val result = BetterLyricsSource(BetterLyricsApi(OkHttpClient())).fetch(q)
            assertNotNull("service returned nothing; check with curl whether this song is cached", result)
            assertEquals(SyncKind.WORD, result!!.body.kind)
            val lines = (result.body as LyricsBody.Words).lines
            assertTrue("expected many lines", lines.size > 10)
            assertTrue("expected multiple words per line", lines.count { it.size > 1 } > lines.size / 2)
            // timestamps must be monotonic within every line
            for (l in lines) for (i in 1 until l.size) assertTrue(l[i].startMs >= l[i - 1].startMs)
        }
    }
}
