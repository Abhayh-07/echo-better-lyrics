package dev.brahmkshatriya.echo.extension

import dev.brahmkshatriya.echo.common.models.Lyrics
import dev.brahmkshatriya.echo.common.models.Track
import dev.brahmkshatriya.echo.extension.core.LineItem
import dev.brahmkshatriya.echo.extension.core.LyricsBody
import dev.brahmkshatriya.echo.extension.core.ResolvedLyrics
import dev.brahmkshatriya.echo.extension.core.WordItem
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Replaces the template's ExtensionUnitTest. Covers the thin layer that touches Echo's model classes. */
class ExtensionUnitTest {
    private val track = Track(id = "t1", title = "Song")

    @Test
    fun wordSyncedBodyMapsToEchoWordByWordWithoutLosingTiming() {
        val body = LyricsBody.Words(
            listOf(
                listOf(WordItem("The ", 18_234, 18_567), WordItem("club", 18_567, 18_901)),
                listOf(WordItem("Next", 20_000, 21_000)),
            ),
        )
        val echo = ResolvedLyrics("Better Lyrics", body, "en", 0.97).toEcho(track)
        val lyric = echo.lyrics as Lyrics.WordByWord
        assertEquals(
            listOf(
                listOf(Lyrics.Item("The ", 18_234, 18_567), Lyrics.Item("club", 18_567, 18_901)),
                listOf(Lyrics.Item("Next", 20_000, 21_000)),
            ),
            lyric.list,
        )
        assertEquals("Better Lyrics · word-synced", echo.subtitle)
        assertEquals("en", echo.extras["language"])
        assertEquals("word", echo.extras["syncType"])
    }

    @Test
    fun lineAndPlainBodiesMapToTimedAndSimple() {
        val timed = ResolvedLyrics("Unison", LyricsBody.Lines(listOf(LineItem("x", 1, 2))), null, null).toEcho(track)
        assertEquals(Lyrics.Timed(listOf(Lyrics.Item("x", 1, 2))), timed.lyrics)
        val plain = ResolvedLyrics("Unison", LyricsBody.Plain("hello"), null, null).toEcho(track)
        assertEquals(Lyrics.Simple("hello"), plain.lyrics)
    }

    @Test
    fun extensionExposesNoSettingsAndLoadLyricsIsIdempotent() = runBlocking {
        val ext = BetterLyricsExtension()
        assertTrue(ext.getSettingItems().isEmpty())
        val l = Lyrics(id = "a", title = "t", lyrics = Lyrics.Simple("x"))
        assertEquals(l, ext.loadLyrics(l))
    }
}
