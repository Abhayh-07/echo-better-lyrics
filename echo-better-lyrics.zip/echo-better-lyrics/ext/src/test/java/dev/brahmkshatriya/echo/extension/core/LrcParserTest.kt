package dev.brahmkshatriya.echo.extension.core

import org.junit.Assert.assertEquals
import org.junit.Test

class LrcParserTest {
    @Test
    fun parsesLinesWithEndTimesFromNextLine() {
        val lrc = "[ar:Someone]\n[00:12.50]First\n[00:15.00]Second\n[00:20]\n[00:25.250]Third"
        val lines = LrcParser.parse(lrc, 40_000)
        assertEquals(
            listOf(
                LineItem("First", 12_500L, 15_000L),
                LineItem("Second", 15_000L, 20_000L),
                LineItem("Third", 25_250L, 40_000L),
            ),
            lines,
        )
    }

    @Test
    fun handlesMultipleTagsAndStripsWordTags() {
        val lines = LrcParser.parse("[00:01.00][00:09.00]<00:01.00>Hel<00:01.50>lo", null)
        assertEquals(listOf("Hello", "Hello"), lines.map { it.text })
        assertEquals(listOf(1_000L, 9_000L), lines.map { it.startMs })
    }

    @Test
    fun garbageYieldsNothing() {
        assertEquals(emptyList<LineItem>(), LrcParser.parse("just words\n\n[ti:x]", null))
    }
}
