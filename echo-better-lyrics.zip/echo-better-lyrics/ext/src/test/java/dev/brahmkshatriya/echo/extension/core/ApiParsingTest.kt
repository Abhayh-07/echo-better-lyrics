package dev.brahmkshatriya.echo.extension.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class ApiParsingTest {
    @Test
    fun betterLyricsSuccessBody() {
        val r = BetterLyricsApi.parseBody("""{"ttml":"<tt/>","score":0.97}""")
        assertNotNull(r)
        assertEquals("<tt/>", r!!.ttml)
        assertEquals(0.97, r.score!!, 1e-9)
    }

    @Test
    fun betterLyricsCacheHitHasNoScore() {
        assertNull(BetterLyricsApi.parseBody("""{"ttml":"<tt/>"}""")!!.score)
    }

    @Test
    fun betterLyricsErrorsAndGarbageAreMisses() {
        assertNull(BetterLyricsApi.parseBody("""{"error":"Lyrics not available for this track"}"""))
        assertNull(BetterLyricsApi.parseBody("""{"ttml":null}"""))
        assertNull(BetterLyricsApi.parseBody("""{"ttml":""}"""))
        assertNull(BetterLyricsApi.parseBody("""{"ttml":{"nested":1}}"""))
        assertNull(BetterLyricsApi.parseBody("[]"))
        assertNull(BetterLyricsApi.parseBody("not json"))
        assertNull(BetterLyricsApi.parseBody(""))
    }

    @Test
    fun unisonSuccessBody() {
        val e = UnisonApi.parseBody(
            """{"success":true,"data":{"id":1,"format":"TTML","syncType":"richsync","language":"en","lyrics":"<tt/>"}}""",
        )
        assertNotNull(e)
        assertEquals("ttml", e!!.format)
        assertEquals("richsync", e.syncType)
        assertEquals("en", e.language)
    }

    @Test
    fun unisonFailuresAreMisses() {
        assertNull(UnisonApi.parseBody("""{"success":false,"error":"Not found","code":"NOT_FOUND"}"""))
        assertNull(UnisonApi.parseBody("""{"success":true,"data":{"format":"lrc"}}"""))
        assertNull(UnisonApi.parseBody("""{"success":true}"""))
        assertNull(UnisonApi.parseBody("<html>502</html>"))
    }
}
