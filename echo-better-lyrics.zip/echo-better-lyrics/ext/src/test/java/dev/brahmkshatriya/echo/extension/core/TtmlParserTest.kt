package dev.brahmkshatriya.echo.extension.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TtmlParserTest {

    private fun ok(ttml: String): TtmlDocument {
        val r = TtmlParser.parse(ttml)
        assertTrue("expected Ok but was $r", r is TtmlResult.Ok)
        return (r as TtmlResult.Ok).document
    }

    // The example from https://docs.betterlyrics.org/docs/response-format, unformatted as real responses are.
    private val docSample =
        """<?xml version="1.0" encoding="UTF-8"?><tt xmlns="http://www.w3.org/ns/ttml"><body><div>""" +
            """<p begin="00:00:18.234" end="00:00:21.891">""" +
            """<span begin="00:00:18.234" end="00:00:18.567">The </span>""" +
            """<span begin="00:00:18.567" end="00:00:18.901">club </span>""" +
            """<span begin="00:00:18.901" end="00:00:19.234">isn't </span>""" +
            """<span begin="00:00:19.234" end="00:00:19.568">the </span>""" +
            """<span begin="00:00:19.568" end="00:00:19.901">best </span>""" +
            """<span begin="00:00:19.901" end="00:00:20.234">place </span>""" +
            """<span begin="00:00:20.234" end="00:00:20.568">to </span>""" +
            """<span begin="00:00:20.568" end="00:00:20.901">find </span>""" +
            """<span begin="00:00:20.901" end="00:00:21.234">a </span>""" +
            """<span begin="00:00:21.234" end="00:00:21.891">lover</span>""" +
            """</p></div></body></tt>"""

    @Test
    fun documentedSampleKeepsEveryWordAndExactTiming() {
        val doc = ok(docSample)
        assertEquals(1, doc.lines.size)
        val line = doc.lines[0]
        assertEquals(10, line.words.size)
        assertEquals(TtmlWord("The ", 18234L, 18567L, false), line.words[0])
        assertEquals(TtmlWord("lover", 21234L, 21891L, false), line.words[9])
        assertEquals("The club isn't the best place to find a lover", line.leadText)
        assertEquals(18234L, line.beginMs)
        assertEquals(21891L, line.endMs)
        assertTrue(doc.isWordSynced)
    }

    @Test
    fun parsesAllDocumentedTimeFormats() {
        assertEquals(90500L, TtmlParser.parseTime("00:01:30.500")!!)
        assertEquals(76656L, TtmlParser.parseTime("1:16.656")!!)
        assertEquals(18234L, TtmlParser.parseTime("18.234")!!)
        assertEquals(12500L, TtmlParser.parseTime("12.5s")!!)
        assertEquals(250L, TtmlParser.parseTime("250ms")!!)
        assertEquals(3_723_004L, TtmlParser.parseTime("1:02:03.004")!!)
    }

    @Test
    fun rejectsMalformedTimes() {
        assertNull(TtmlParser.parseTime(null))
        assertNull(TtmlParser.parseTime(""))
        assertNull(TtmlParser.parseTime("abc"))
        assertNull(TtmlParser.parseTime("NaN"))
        assertNull(TtmlParser.parseTime("-5"))
        assertNull(TtmlParser.parseTime("1:2:3:4"))
        assertNull(TtmlParser.parseTime("1e3"))
    }

    @Test
    fun bareWhitespaceBetweenSpansBecomesTheSpaceBetweenWords() {
        val doc = ok(
            """<tt xmlns="http://www.w3.org/ns/ttml"><body><div><p begin="0:05.123" end="0:08.456">""" +
                """<span begin="0:05.123" end="0:05.500">Hel</span><span begin="0:05.500" end="0:06.000">lo</span> """ +
                """<span begin="0:06.000" end="0:08.456">world</span></p></div></body></tt>""",
        )
        val words = doc.lines[0].words
        assertEquals(listOf("Hel", "lo ", "world"), words.map { it.text })
        assertEquals("Hello world", doc.lines[0].leadText)
    }

    @Test
    fun prettyPrintedIndentationDoesNotInjectSpaces() {
        val doc = ok(
            "<tt><body><div>\n<p begin=\"0:01.000\" end=\"0:02.000\">\n  " +
                "<span begin=\"0:01.000\" end=\"0:01.500\">He</span>\n  " +
                "<span begin=\"0:01.500\" end=\"0:02.000\">llo</span>\n</p>\n</div></body></tt>",
        )
        assertEquals("Hello", doc.lines[0].leadText)
    }

    @Test
    fun keepsAgentLanguageAndAgentNames() {
        val doc = ok(
            """<tt xmlns="http://www.w3.org/ns/ttml" xmlns:ttm="http://www.w3.org/ns/ttml#metadata" xml:lang="ja">""" +
                """<head><metadata><ttm:agent type="person" xml:id="v1"><ttm:name type="full">Artist Name</ttm:name></ttm:agent>""" +
                """</metadata></head><body><div><p ttm:agent="v1" begin="0:01.000" end="0:03.000">""" +
                """<span begin="0:01.000" end="0:02.000">A </span><span begin="0:02.000" end="0:03.000">b</span></p></div></body></tt>""",
        )
        assertEquals("ja", doc.language)
        assertEquals("Artist Name", doc.agents["v1"])
        assertEquals("v1", doc.lines[0].agent)
    }

    @Test
    fun backgroundVocalsAreFlaggedAndBecomeTheirOwnLine() {
        val doc = ok(
            """<tt xmlns="http://www.w3.org/ns/ttml" xmlns:ttm="http://www.w3.org/ns/ttml#metadata"><body><div>""" +
                """<p ttm:agent="v1" begin="0:15.000" end="0:20.000">""" +
                """<span begin="0:15.000" end="0:17.500">Lead </span><span begin="0:17.500" end="0:17.800">lyrics </span>""" +
                """<span ttm:role="x-bg"><span begin="0:17.500" end="0:20.000">background vocals</span></span></p></div></body></tt>""",
        )
        val line = doc.lines[0]
        assertEquals(listOf(false, false, true), line.words.map { it.isBackground })
        assertEquals("Lead lyrics", line.leadText)
        assertEquals("background vocals", line.backgroundText)

        val body = TtmlConverter.toBody(doc) as LyricsBody.Words
        assertEquals(2, body.lines.size)
        assertEquals(listOf("Lead ", "lyrics"), body.lines[0].map { it.text })
        assertEquals(listOf(WordItem("background vocals", 17500L, 20000L)), body.lines[1])
    }

    @Test
    fun lineOnlyTtmlFallsBackToLineSync() {
        val doc = ok("""<tt><body><div><p begin="0:01.000" end="0:03.000">Just a line</p><p begin="0:03.000" end="0:05.000">Another</p></div></body></tt>""")
        assertFalse(doc.isWordSynced)
        val body = TtmlConverter.toBody(doc) as LyricsBody.Lines
        assertEquals(
            listOf(LineItem("Just a line", 1000L, 3000L), LineItem("Another", 3000L, 5000L)),
            body.lines,
        )
    }

    @Test
    fun missingSpanEndUsesNextWordStart() {
        val doc = ok("""<tt><body><div><p begin="0:01.000" end="0:03.000"><span begin="0:01.000">One </span><span begin="0:02.000" end="0:03.000">two</span></p></div></body></tt>""")
        assertEquals(2000L, doc.lines[0].words[0].endMs)
    }

    @Test
    fun instrumentalMarkersAreNotLyrics() {
        val doc = ok("""<tt><body><div><p begin="0:01.000" end="0:03.000">♪</p></div></body></tt>""")
        assertFalse(doc.hasSingableText)
        assertNull(TtmlConverter.toBody(doc))
    }

    @Test
    fun malformedOrHostileInputFailsWithoutThrowing() {
        assertTrue(TtmlParser.parse("") is TtmlResult.Failure)
        assertTrue(TtmlParser.parse("<tt><body><p>") is TtmlResult.Failure)
        assertTrue(TtmlParser.parse("not xml at all") is TtmlResult.Failure)
        assertTrue(TtmlParser.parse("<tt><body/></tt>") is TtmlResult.Failure) // no lines
        val xxe = """<?xml version="1.0"?><!DOCTYPE tt [<!ENTITY x SYSTEM "file:///etc/passwd">]><tt><body><div><p begin="0:01.000" end="0:02.000">&x;</p></div></body></tt>"""
        val r = TtmlParser.parse(xxe)
        assertTrue("DTD must be rejected, was $r", r is TtmlResult.Failure)
    }

    @Test
    fun deepNestingDoesNotOverflowTheStack() {
        val open = "<span>".repeat(5_000)
        val close = "</span>".repeat(5_000)
        val r = TtmlParser.parse("""<tt><body><div><p begin="0:01.000" end="0:02.000">$open<span begin="0:01.000" end="0:02.000">x</span>$close</p></div></body></tt>""")
        assertNotNull(r) // Ok or Failure are both acceptable; reaching here means no StackOverflowError
    }

    @Test
    fun durationSanityRejectsLyricsThatOutlastTheTrack() {
        assertTrue(Sanity.fitsDuration(200_000, 154_000).not())
        assertTrue(Sanity.fitsDuration(160_000, 154_000))
        assertTrue(Sanity.fitsDuration(999_999, null))
    }
}
