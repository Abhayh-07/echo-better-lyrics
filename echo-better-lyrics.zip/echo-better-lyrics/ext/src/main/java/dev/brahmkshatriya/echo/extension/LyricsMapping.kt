package dev.brahmkshatriya.echo.extension

import dev.brahmkshatriya.echo.common.models.Lyrics
import dev.brahmkshatriya.echo.common.models.Track
import dev.brahmkshatriya.echo.extension.core.LyricsBody
import dev.brahmkshatriya.echo.extension.core.ResolvedLyrics
import dev.brahmkshatriya.echo.extension.core.SyncKind

/**
 * Echo's Lyrics.Item has startTime/endTime as Long with the unit undocumented in the published API docs.
 * Everything upstream is in milliseconds (as is Track.duration). If Echo turns out to expect another unit,
 * change this one constant.
 */
internal const val ECHO_TIME_SCALE = 1L

/**
 * Word items keep their trailing space (e.g. "The ") exactly as delivered by the API. If Echo's renderer
 * inserts its own space between items, set this to false to avoid double spaces.
 */
internal const val KEEP_TRAILING_SPACES = true

internal fun ResolvedLyrics.toEcho(track: Track): Lyrics {
    fun item(text: String, start: Long, end: Long) =
        Lyrics.Item(if (KEEP_TRAILING_SPACES) text else text.trimEnd(), start * ECHO_TIME_SCALE, end * ECHO_TIME_SCALE)

    val lyric: Lyrics.Lyric = when (val b = body) {
        is LyricsBody.Words -> Lyrics.WordByWord(b.lines.map { line -> line.map { item(it.text, it.startMs, it.endMs) } })
        is LyricsBody.Lines -> Lyrics.Timed(b.lines.map { item(it.text, it.startMs, it.endMs) })
        is LyricsBody.Plain -> Lyrics.Simple(b.text)
    }
    val label = when (body.kind) {
        SyncKind.WORD -> "word-synced"
        SyncKind.LINE -> "line-synced"
        SyncKind.PLAIN -> "unsynced"
    }
    val extras = buildMap<String, String> {
        put("source", source)
        put("syncType", body.kind.name.lowercase())
        language?.let { put("language", it) }
        score?.let { put("score", it.toString()) }
    }
    return Lyrics(
        id = "better_lyrics:${source.lowercase()}:${track.id}",
        title = track.title,
        subtitle = "$source · $label",
        lyrics = lyric,
        extras = extras,
    )
}
