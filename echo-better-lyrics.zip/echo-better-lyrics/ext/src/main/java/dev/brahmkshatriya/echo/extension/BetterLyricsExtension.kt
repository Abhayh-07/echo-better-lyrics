package dev.brahmkshatriya.echo.extension

import dev.brahmkshatriya.echo.common.clients.LyricsClient
import dev.brahmkshatriya.echo.common.models.Feed
import dev.brahmkshatriya.echo.common.models.Feed.Companion.toFeed
import dev.brahmkshatriya.echo.common.models.Lyrics
import dev.brahmkshatriya.echo.common.models.Track
import dev.brahmkshatriya.echo.common.settings.Setting
import dev.brahmkshatriya.echo.common.settings.Settings
import dev.brahmkshatriya.echo.extension.core.BetterLyricsApi
import dev.brahmkshatriya.echo.extension.core.BetterLyricsSource
import dev.brahmkshatriya.echo.extension.core.LyricsResolver
import dev.brahmkshatriya.echo.extension.core.UnisonApi
import dev.brahmkshatriya.echo.extension.core.UnisonSource
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * Lyrics extension: Better Lyrics API (syllable-level TTML) + Unison community database,
 * falling back to line-synced and then plain lyrics when word timing is unavailable.
 */
class BetterLyricsExtension : LyricsClient {

    private val http: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .callTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    private val resolver: LyricsResolver by lazy {
        LyricsResolver(listOf(BetterLyricsSource(BetterLyricsApi(http)), UnisonSource(UnisonApi(http))))
    }

    // No user-configurable settings: the service needs no key for cached songs and none is bundled.
    override suspend fun getSettingItems(): List<Setting> = emptyList()

    private lateinit var settings: Settings
    override fun setSettings(settings: Settings) {
        this.settings = settings
    }

    /**
     * Results are returned already loaded (Lyrics.lyrics != null), best sync quality first, so Echo can use
     * the first one directly. Missing lyrics, instrumentals, timeouts and malformed responses all yield an
     * empty feed rather than an exception.
     */
    override suspend fun searchTrackLyrics(clientId: String, track: Track): Feed<Lyrics> {
        val query = track.toQuery() ?: return emptyList<Lyrics>().toFeed()
        return resolver.resolve(query).map { it.toEcho(track) }.toFeed()
    }

    /** Search results are already loaded, so there is nothing further to fetch. */
    override suspend fun loadLyrics(lyrics: Lyrics): Lyrics = lyrics
}
