package dev.brahmkshatriya.echo.extension.core

import org.w3c.dom.Element
import org.w3c.dom.Node
import org.xml.sax.InputSource
import java.io.StringReader
import javax.xml.parsers.DocumentBuilder
import javax.xml.parsers.DocumentBuilderFactory

data class TtmlWord(val text: String, val beginMs: Long, val endMs: Long, val isBackground: Boolean)

data class TtmlLine(
    val beginMs: Long,
    val endMs: Long,
    /** Value of ttm:agent on the <p>, e.g. "v1" / "v2" / "v1000". Kept for callers; Echo's model cannot carry it. */
    val agent: String?,
    val words: List<TtmlWord>,
    /** True when the source <p> contained timed <span>s; false when only line timing existed. */
    val hasWordTiming: Boolean,
) {
    val leadText: String get() = words.filter { !it.isBackground }.joinToString("") { it.text }.trim()
    val backgroundText: String get() = words.filter { it.isBackground }.joinToString("") { it.text }.trim()
}

data class TtmlDocument(
    val lines: List<TtmlLine>,
    val language: String?,
    /** ttm:agent id -> display name (may be null). */
    val agents: Map<String, String?>,
) {
    val isWordSynced: Boolean get() = lines.any { it.hasWordTiming && it.words.size >= 2 }
    val lastEndMs: Long get() = lines.maxOfOrNull { it.endMs } ?: 0L
    val hasSingableText: Boolean
        get() = lines.any { l -> l.words.any { w -> w.text.any { c -> c.isLetterOrDigit() } } }
}

sealed interface TtmlResult {
    data class Ok(val document: TtmlDocument) : TtmlResult
    data class Failure(val reason: String) : TtmlResult
}

/**
 * Parser for the TTML documented at https://docs.betterlyrics.org/docs/response-format
 * (Apple-style TTML: <p> lines, timed <span> words/syllables, ttm:agent, ttm:role="x-bg").
 *
 * Never throws on bad input; returns [TtmlResult.Failure] instead.
 */
object TtmlParser {
    private const val MAX_INPUT_CHARS = 4_000_000
    private const val MAX_LINES = 10_000
    private const val MAX_DEPTH = 64

    private val DTD = Regex("<!\\s*(DOCTYPE|ENTITY)", RegexOption.IGNORE_CASE)
    private val SECONDS = Regex("\\d{1,9}(\\.\\d{1,9})?")
    private val INTEGER = Regex("\\d{1,9}")
    private val WHITESPACE_RUN = Regex("\\s+")

    private class MutableWord(var text: String, val begin: Long, val end: Long?, val background: Boolean)

    private class LineBuilder {
        val words = ArrayList<MutableWord>()
        val loose = StringBuilder()
        var sawTimedSpan = false
    }

    fun parse(ttml: String): TtmlResult {
        if (ttml.isBlank()) return TtmlResult.Failure("empty document")
        if (ttml.length > MAX_INPUT_CHARS) return TtmlResult.Failure("document too large")
        // Lyrics TTML never needs a DTD; refusing it removes XXE / entity-expansion risk on every platform.
        if (DTD.containsMatchIn(ttml)) return TtmlResult.Failure("DTD/entity declarations are not accepted")

        val root: Element?
        try {
            root = newBuilder().parse(InputSource(StringReader(ttml))).documentElement
        } catch (e: Exception) {
            return TtmlResult.Failure("malformed XML: ${e.message}")
        } catch (e: StackOverflowError) {
            return TtmlResult.Failure("document nesting too deep")
        }
        if (root == null) return TtmlResult.Failure("no root element")

        val agents = LinkedHashMap<String, String?>()
        collectAgents(root, agents, 0)

        val paragraphs = ArrayList<Element>()
        collectParagraphs(root, paragraphs, 0)

        val lines = ArrayList<TtmlLine>()
        for (p in paragraphs) {
            if (lines.size >= MAX_LINES) break
            parseLine(p)?.let { lines.add(it) }
        }
        if (lines.isEmpty()) return TtmlResult.Failure("no timed lyric lines")

        val lang = root.attr("lang")?.trim()?.takeIf { it.isNotEmpty() }
        return TtmlResult.Ok(TtmlDocument(lines, lang, agents))
    }

    /**
     * Accepts "HH:MM:SS.mmm", "M:SS.mmm", "SS.mmm", "12.5s" and "250ms". Returns milliseconds,
     * or null for anything else (including negative numbers, NaN, and SMPTE frame timecodes).
     */
    fun parseTime(raw: String?): Long? {
        val s = raw?.trim() ?: return null
        if (s.isEmpty()) return null
        return when {
            s.endsWith("ms") -> s.removeSuffix("ms").trim().takeIf { SECONDS.matches(it) }?.let { Math.round(it.toDouble()) }
            s.endsWith("s") -> s.removeSuffix("s").trim().takeIf { SECONDS.matches(it) }?.let { Math.round(it.toDouble() * 1000.0) }
            s.contains(':') -> parseClock(s)
            SECONDS.matches(s) -> Math.round(s.toDouble() * 1000.0)
            else -> null
        }
    }

    private fun parseClock(s: String): Long? {
        val parts = s.split(':')
        if (parts.size !in 2..3) return null
        val seconds = parts.last().takeIf { SECONDS.matches(it) }?.toDouble() ?: return null
        val minutes = parts[parts.size - 2].takeIf { INTEGER.matches(it) }?.toLong() ?: return null
        val hours = if (parts.size == 3) (parts[0].takeIf { INTEGER.matches(it) }?.toLong() ?: return null) else 0L
        return (hours * 3600L + minutes * 60L) * 1000L + Math.round(seconds * 1000.0)
    }

    private fun newBuilder(): DocumentBuilder {
        val f = DocumentBuilderFactory.newInstance()
        f.isNamespaceAware = false // we match on prefixed names, which is what these documents use
        f.isIgnoringComments = true
        f.isCoalescing = true
        // Best effort: not every XML implementation (notably Android's) supports every feature flag.
        for ((feature, value) in listOf(
            "http://apache.org/xml/features/disallow-doctype-decl" to true,
            "http://xml.org/sax/features/external-general-entities" to false,
            "http://xml.org/sax/features/external-parameter-entities" to false,
        )) {
            try {
                f.setFeature(feature, value)
            } catch (e: Exception) {
                // feature not supported by this XML implementation; the DOCTYPE pre-check still applies
            }
        }
        return f.newDocumentBuilder()
    }

    private fun Element.local(): String = nodeName.substringAfter(':')

    /** Attribute lookup by local name, so "ttm:role", "xml:lang" and plain "begin" all work. */
    private fun Element.attr(local: String): String? {
        val attrs = attributes ?: return null
        for (i in 0 until attrs.length) {
            val a = attrs.item(i)
            val name = a.nodeName
            if (name == local || name.endsWith(":$local")) return a.nodeValue
        }
        return null
    }

    private fun collectParagraphs(node: Node, out: MutableList<Element>, depth: Int) {
        if (depth > MAX_DEPTH) return
        var child = node.firstChild
        while (child != null) {
            if (child.nodeType == Node.ELEMENT_NODE) {
                val el = child as Element
                if (el.local() == "p") out.add(el) else collectParagraphs(el, out, depth + 1)
            }
            child = child.nextSibling
        }
    }

    private fun collectAgents(node: Node, out: MutableMap<String, String?>, depth: Int) {
        if (depth > MAX_DEPTH) return
        var child = node.firstChild
        while (child != null) {
            if (child.nodeType == Node.ELEMENT_NODE) {
                val el = child as Element
                when (el.local()) {
                    "agent" -> el.attr("id")?.let { out[it] = firstChildText(el, "name") }
                    "body" -> {}
                    else -> collectAgents(el, out, depth + 1)
                }
            }
            child = child.nextSibling
        }
    }

    private fun firstChildText(el: Element, local: String): String? {
        var c = el.firstChild
        while (c != null) {
            if (c.nodeType == Node.ELEMENT_NODE && (c as Element).local() == local) {
                return c.textContent?.trim()?.takeIf { it.isNotEmpty() }
            }
            c = c.nextSibling
        }
        return null
    }

    private fun parseLine(p: Element): TtmlLine? {
        val b = LineBuilder()
        collectInline(p, false, b, 0)

        val pBegin = parseTime(p.attr("begin"))
        val pEnd = parseTime(p.attr("end"))
        val agent = p.attr("agent")?.trim()?.takeIf { it.isNotEmpty() }

        if (b.words.isEmpty()) {
            // Line-level timing only: the text sits directly in <p>.
            val text = b.loose.toString().replace(WHITESPACE_RUN, " ").trim()
            if (text.isEmpty() || pBegin == null) return null
            val end = (pEnd ?: pBegin).coerceAtLeast(pBegin)
            return TtmlLine(pBegin, end, agent, listOf(TtmlWord(text, pBegin, end, false)), false)
        }

        val raw = b.words
        val resolved = raw.mapIndexed { i, w ->
            val end = (w.end ?: raw.getOrNull(i + 1)?.begin ?: pEnd ?: w.begin).coerceAtLeast(w.begin)
            TtmlWord(w.text, w.begin, end, w.background)
        }
        val words = trimEdges(resolved)
        if (words.isEmpty()) return null

        val begin = pBegin ?: words.minOf { it.beginMs }
        val end = (pEnd ?: words.maxOf { it.endMs }).coerceAtLeast(begin)
        return TtmlLine(begin, end, agent, words, b.sawTimedSpan)
    }

    private fun collectInline(node: Node, inBackground: Boolean, b: LineBuilder, depth: Int) {
        if (depth > MAX_DEPTH) return
        var child = node.firstChild
        while (child != null) {
            when (child.nodeType) {
                Node.TEXT_NODE, Node.CDATA_SECTION_NODE -> onText(child.nodeValue.orEmpty(), b)
                Node.ELEMENT_NODE -> {
                    val el = child as Element
                    if (el.local() == "span") onSpan(el, inBackground, b, depth)
                }
            }
            child = child.nextSibling
        }
    }

    private fun onText(text: String, b: LineBuilder) {
        if (text.isEmpty()) return
        if (text.isBlank()) {
            // Unformatted responses use bare whitespace between spans as the real space between words.
            // Pretty-printed documents use newlines/indentation, which carry no meaning.
            if (!text.contains('\n') && !text.contains('\r')) b.words.lastOrNull()?.let { appendSpace(it) }
        } else {
            b.loose.append(text)
        }
    }

    private fun onSpan(el: Element, inBackground: Boolean, b: LineBuilder, depth: Int) {
        val background = inBackground || el.attr("role") == "x-bg"
        val beginRaw = el.attr("begin")
        if (beginRaw == null) {
            collectInline(el, background, b, depth + 1) // wrapper span, e.g. the x-bg container
            return
        }
        val text = el.textContent.orEmpty()
        val begin = parseTime(beginRaw)
        if (begin == null) {
            b.loose.append(text) // keep the words, drop the unusable timing
            return
        }
        if (text.isEmpty()) return
        if (text.isBlank()) {
            b.words.lastOrNull()?.let { appendSpace(it) }
            return
        }
        b.sawTimedSpan = true
        val end = parseTime(el.attr("end")) ?: parseTime(el.attr("dur"))?.let { begin + it }
        b.words.add(MutableWord(text, begin, end, background))
    }

    private fun appendSpace(w: MutableWord) {
        if (w.text.isNotEmpty() && !w.text.last().isWhitespace()) w.text += " "
    }

    /** Lead and background vocals are trimmed independently, since they are emitted as separate lines. */
    private fun trimEdges(words: List<TtmlWord>): List<TtmlWord> {
        val out = words.toMutableList()
        for (bg in listOf(false, true)) {
            val idx = out.indices.filter { out[it].isBackground == bg }
            if (idx.isEmpty()) continue
            out[idx.first()] = out[idx.first()].let { it.copy(text = it.text.trimStart()) }
            out[idx.last()] = out[idx.last()].let { it.copy(text = it.text.trimEnd()) }
        }
        return out.filter { it.text.isNotEmpty() }
    }
}
