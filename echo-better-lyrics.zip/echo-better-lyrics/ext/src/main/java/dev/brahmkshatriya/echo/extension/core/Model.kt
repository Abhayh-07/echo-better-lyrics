package dev.brahmkshatriya.echo.extension.core

/** One word or syllable with its timing, in milliseconds from the start of the track. */
data class WordItem(val text: String, val startMs: Long, val endMs: Long)

/** One lyric line with its timing, in milliseconds from the start of the track. */
data class LineItem(val text: String, val startMs: Long, val endMs: Long)

/** How precisely lyrics are synchronized. Declaration order is the preference order. */
enum class SyncKind { WORD, LINE, PLAIN }

sealed interface LyricsBody {
    val kind: SyncKind

    /** Each inner list is one displayed line made of timed words/syllables. */
    data class Words(val lines: List<List<WordItem>>) : LyricsBody {
        override val kind: SyncKind get() = SyncKind.WORD
    }

    data class Lines(val lines: List<LineItem>) : LyricsBody {
        override val kind: SyncKind get() = SyncKind.LINE
    }

    data class Plain(val text: String) : LyricsBody {
        override val kind: SyncKind get() = SyncKind.PLAIN
    }
}

data class ResolvedLyrics(
    val source: String,
    val body: LyricsBody,
    val language: String?,
    val score: Double?,
)

/** What we know about a track, independent of Echo's model classes. */
data class TrackQuery(
    val title: String,
    val primaryArtist: String,
    val allArtists: String,
    val album: String?,
    val durationMs: Long?,
) {
    /** Better Lyrics and Unison both want whole seconds. */
    val durationSec: Long? get() = durationMs?.takeIf { it > 0 }?.let { (it + 500) / 1000 }
}

sealed interface Outcome<out T> {
    data class Hit<T>(val value: T) : Outcome<T>
    data class Miss(val reason: String) : Outcome<Nothing>
}

interface LyricsSource {
    val name: String

    /** Returns null when this source has nothing usable. Must not throw for ordinary failures. */
    suspend fun fetch(query: TrackQuery): ResolvedLyrics?
}
