package dev.brahmkshatriya.echo.extension.core

import dev.brahmkshatriya.echo.common.helpers.ContinuationCallback.Companion.await
import kotlinx.coroutines.CancellationException
import okhttp3.OkHttpClient
import okhttp3.Request

internal const val USER_AGENT = "EchoBetterLyricsExtension/1.0"
private const val MAX_BODY_BYTES = 4_000_000L

internal sealed interface HttpResult {
    data class Ok(val body: String) : HttpResult
    data class Status(val code: Int, val retryAfter: String?) : HttpResult
    data class Failed(val reason: String) : HttpResult
}

/** Never throws except for coroutine cancellation: timeouts, DNS and TLS problems become [HttpResult.Failed]. */
internal suspend fun OkHttpClient.fetchText(request: Request): HttpResult =
    try {
        newCall(request).await().use { resp ->
            if (resp.isSuccessful) {
                HttpResult.Ok(resp.peekBody(MAX_BODY_BYTES).string())
            } else {
                HttpResult.Status(resp.code, resp.header("Retry-After"))
            }
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        HttpResult.Failed("${e.javaClass.simpleName}: ${e.message}")
    }
