package dev.brahmkshatriya.echo.extension.core

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request

/** GET /lyrics?song=&artist=&album=&duration= as documented at https://docs.betterlyrics.org/unison (no key needed). */
class UnisonApi(
    private val http: OkHttpClient,
    private val baseUrl: HttpUrl = HttpUrl.Builder().scheme("https").host("unison.boidu.dev").build(),
) {
    data class Entry(val format: String, val syncType: String?, val language: String?, val lyrics: String)

    suspend fun getLyrics(q: TrackQuery): Outcome<Entry> {
        val url = baseUrl.newBuilder()
            .addPathSegment("lyrics")
            .addQueryParameter("song", q.title)
            .addQueryParameter("artist", q.primaryArtist) // Unison matches artist exactly (case-insensitive)
            .apply {
                q.album?.let { addQueryParameter("album", it) }
                q.durationSec?.let { addQueryParameter("duration", it.toString()) }
            }
            .build()
        val request = Request.Builder().url(url)
            .header("Accept", "application/json")
            .header("User-Agent", USER_AGENT)
            .build()

        return when (val r = http.fetchText(request)) {
            is HttpResult.Ok -> parseBody(r.body)?.let { Outcome.Hit(it) } ?: Outcome.Miss("malformed or unsuccessful response")
            is HttpResult.Status -> Outcome.Miss(if (r.code == 404) "no match" else "HTTP ${r.code}")
            is HttpResult.Failed -> Outcome.Miss(r.reason)
        }
    }

    companion object {
        /** Expects {"success": true, "data": {"format": "...", "lyrics": "...", ...}}. */
        fun parseBody(body: String): Entry? = try {
            val root = Json.parseToJsonElement(body).jsonObject
            if (root["success"]?.jsonPrimitive?.booleanOrNull != true) {
                null
            } else {
                val data = root["data"]?.jsonObject
                val format = data?.get("format")?.jsonPrimitive?.contentOrNull?.lowercase()
                val lyrics = data?.get("lyrics")?.jsonPrimitive?.contentOrNull
                if (data == null || format.isNullOrBlank() || lyrics.isNullOrBlank()) {
                    null
                } else {
                    Entry(
                        format = format,
                        syncType = data["syncType"]?.jsonPrimitive?.contentOrNull,
                        language = data["language"]?.jsonPrimitive?.contentOrNull,
                        lyrics = lyrics,
                    )
                }
            }
        } catch (e: IllegalArgumentException) {
            null
        }
    }
}
