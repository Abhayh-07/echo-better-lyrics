package dev.brahmkshatriya.echo.extension.core

/** Minimal LRC reader for line-synced fallback. Enhanced-LRC word tags are stripped, not interpreted. */
object LrcParser {
    private const val DEFAULT_LAST_LINE_MS = 5_000L
    private val TIME_TAG = Regex("""\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?]""")
    private val WORD_TAG = Regex("""<\d{1,3}:\d{1,2}(?:[.:]\d{1,3})?>""")

    fun parse(lrc: String, durationMs: Long?): List<LineItem> {
        val stamped = ArrayList<Pair<Long, String>>()
        for (raw in lrc.lineSequence()) {
            var rest = raw.trim()
            val starts = ArrayList<Long>()
            while (true) {
                val m = TIME_TAG.find(rest)
                if (m == null || m.range.first != 0) break
                starts.add(toMs(m))
                rest = rest.substring(m.range.last + 1)
            }
            if (starts.isEmpty()) continue // metadata such as [ar:...] or free text
            val text = WORD_TAG.replace(rest, "").trim()
            for (s in starts) stamped.add(s to text)
        }

        val sorted = stamped.sortedBy { it.first } // stable
        val out = ArrayList<LineItem>()
        for (i in sorted.indices) {
            val (start, text) = sorted[i]
            if (text.isBlank()) continue
            val end = sorted.getOrNull(i + 1)?.first
                ?: durationMs?.takeIf { it > start }
                ?: (start + DEFAULT_LAST_LINE_MS)
            out.add(LineItem(text, start, end.coerceAtLeast(start)))
        }
        return out
    }

    private fun toMs(m: MatchResult): Long {
        val minutes = m.groupValues[1].toLong()
        val seconds = m.groupValues[2].toLong()
        val frac = m.groupValues[3]
        val fracMs = when (frac.length) {
            0 -> 0L
            1 -> frac.toLong() * 100
            2 -> frac.toLong() * 10
            else -> frac.toLong()
        }
        return (minutes * 60 + seconds) * 1000 + fracMs
    }
}
