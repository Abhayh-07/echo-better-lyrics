package dev.brahmkshatriya.echo.extension.core

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope

/** Small thread-safe LRU cache with expiry. */
class TtlCache<K : Any, V : Any>(
    private val maxSize: Int,
    private val ttlMs: Long,
    private val now: () -> Long = { System.currentTimeMillis() },
) {
    private class Entry<V>(val value: V, val expiresAt: Long)

    private val map = object : LinkedHashMap<K, Entry<V>>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<K, Entry<V>>?): Boolean = size > maxSize
    }

    fun get(key: K): V? = synchronized(map) {
        val e = map[key] ?: return null
        if (e.expiresAt <= now()) {
            map.remove(key)
            null
        } else {
            e.value
        }
    }

    fun put(key: K, value: V) {
        synchronized(map) { map[key] = Entry(value, now() + ttlMs) }
    }
}

/**
 * Queries every source in parallel and returns what was found, most precise first
 * (word-synced, then line-synced, then plain). One failing source never hides another's result.
 * Only successful lookups are cached, so a network blip is retried on the next request.
 */
class LyricsResolver(
    private val sources: List<LyricsSource>,
    private val cache: TtlCache<TrackQuery, List<ResolvedLyrics>> = TtlCache(32, 30 * 60_000L),
) {
    suspend fun resolve(query: TrackQuery): List<ResolvedLyrics> {
        cache.get(query)?.let { return it }
        val found = coroutineScope {
            sources.map { s -> async { safeFetch(s, query) } }.awaitAll()
        }.filterNotNull().sortedBy { it.body.kind.ordinal }
        if (found.isNotEmpty()) cache.put(query, found)
        return found
    }

    private suspend fun safeFetch(source: LyricsSource, query: TrackQuery): ResolvedLyrics? =
        try {
            source.fetch(query)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
}
