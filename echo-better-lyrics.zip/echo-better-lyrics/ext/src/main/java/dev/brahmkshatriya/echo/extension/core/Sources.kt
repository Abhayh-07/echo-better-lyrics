package dev.brahmkshatriya.echo.extension.core

class BetterLyricsSource(private val api: BetterLyricsApi) : LyricsSource {
    override val name: String = "Better Lyrics"

    override suspend fun fetch(query: TrackQuery): ResolvedLyrics? {
        val hit = (api.getLyrics(query) as? Outcome.Hit)?.value ?: return null
        return TtmlConverter.resolve(name, hit.ttml, query, hit.score)
    }
}

class UnisonSource(private val api: UnisonApi) : LyricsSource {
    override val name: String = "Unison"

    override suspend fun fetch(query: TrackQuery): ResolvedLyrics? {
        val entry = (api.getLyrics(query) as? Outcome.Hit)?.value ?: return null
        return when (entry.format) {
            "ttml" -> TtmlConverter.resolve(name, entry.lyrics, query, null)
            "lrc" -> {
                val lines = LrcParser.parse(entry.lyrics, query.durationMs)
                if (lines.isEmpty() || !Sanity.fitsDuration(lines.last().startMs, query.durationMs)) {
                    null
                } else {
                    ResolvedLyrics(name, LyricsBody.Lines(lines), entry.language, null)
                }
            }
            "plain" -> entry.lyrics.trim().takeIf { t -> t.any { it.isLetterOrDigit() } }
                ?.let { ResolvedLyrics(name, LyricsBody.Plain(it), entry.language, null) }
            else -> null
        }
    }
}
