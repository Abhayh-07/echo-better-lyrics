package dev.brahmkshatriya.echo.extension.core

object Sanity {
    /** Lyrics may end well before a track does (outros), but not long after it: that means a different recording. */
    const val DURATION_SLACK_MS = 15_000L

    fun fitsDuration(lastTimestampMs: Long, trackDurationMs: Long?): Boolean =
        trackDurationMs == null || trackDurationMs <= 0 || lastTimestampMs <= trackDurationMs + DURATION_SLACK_MS
}

object TtmlConverter {
    /** Null means "no usable lyrics" (empty, or instrumental markers only). */
    fun toBody(doc: TtmlDocument): LyricsBody? {
        if (!doc.hasSingableText) return null
        return if (doc.isWordSynced) words(doc) else lines(doc)
    }

    /**
     * Echo's WordByWord is a list of lines. Background vocals overlap the lead vocal in time, so they are
     * emitted as their own line right after it instead of being interleaved into the lead line.
     */
    private fun words(doc: TtmlDocument): LyricsBody.Words {
        val out = ArrayList<List<WordItem>>()
        for (line in doc.lines) {
            val lead = line.words.filter { !it.isBackground }.map { WordItem(it.text, it.beginMs, it.endMs) }
            val bg = line.words.filter { it.isBackground }.map { WordItem(it.text, it.beginMs, it.endMs) }
            if (lead.isNotEmpty()) out.add(lead)
            if (bg.isNotEmpty()) out.add(bg)
        }
        return LyricsBody.Words(out)
    }

    private fun lines(doc: TtmlDocument): LyricsBody.Lines {
        val out = ArrayList<LineItem>()
        for (line in doc.lines) {
            val text = line.leadText.ifEmpty { line.backgroundText }
            if (text.isNotEmpty()) out.add(LineItem(text, line.beginMs, line.endMs))
        }
        return LyricsBody.Lines(out)
    }

    /** Shared by every source that delivers TTML. */
    fun resolve(source: String, ttml: String, query: TrackQuery, score: Double?): ResolvedLyrics? {
        val doc = (TtmlParser.parse(ttml) as? TtmlResult.Ok)?.document ?: return null
        if (!Sanity.fitsDuration(doc.lastEndMs, query.durationMs)) return null
        val body = toBody(doc) ?: return null
        return ResolvedLyrics(source, body, doc.language, score)
    }
}
