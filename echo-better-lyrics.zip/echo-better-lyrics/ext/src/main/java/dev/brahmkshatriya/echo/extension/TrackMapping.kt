package dev.brahmkshatriya.echo.extension

import dev.brahmkshatriya.echo.common.models.Track
import dev.brahmkshatriya.echo.extension.core.TrackQuery

/**
 * VERIFY ON FIRST COMPILE: Artist.name and Album.title are the only Echo model members used here that I could
 * not confirm from the published API docs (Track.title/artists/album/duration, Lyrics, Feed were confirmed).
 * If either name differs, this is the single place to fix.
 */
internal fun Track.toQuery(): TrackQuery? {
    val cleanTitle = title.trim()
    val names = artists.map { it.name.trim() }.filter { it.isNotEmpty() }
    if (cleanTitle.isEmpty() || names.isEmpty()) return null // both services need title and artist
    return TrackQuery(
        title = cleanTitle,
        primaryArtist = names.first(),
        allArtists = names.joinToString(", "),
        album = album?.title?.trim()?.takeIf { it.isNotEmpty() },
        durationMs = duration?.takeIf { it > 0 },
    )
}
