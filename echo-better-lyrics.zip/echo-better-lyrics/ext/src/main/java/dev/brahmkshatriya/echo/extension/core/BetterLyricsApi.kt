package dev.brahmkshatriya.echo.extension.core

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request

/**
 * GET /getLyrics as documented at https://docs.betterlyrics.org/reference/get-lyrics
 *
 * No API key is sent. The service answers cached songs without one and returns 401 for uncached songs;
 * that is reported as a miss so other sources can be tried. See README for why no key is bundled.
 */
class BetterLyricsApi(
    private val http: OkHttpClient,
    private val baseUrl: HttpUrl = HttpUrl.Builder().scheme("https").host("api.betterlyrics.org").build(),
) {
    data class Response(val ttml: String, val score: Double?)

    suspend fun getLyrics(q: TrackQuery): Outcome<Response> {
        val url = baseUrl.newBuilder()
            .addPathSegment("getLyrics")
            .addQueryParameter("s", q.title)
            .addQueryParameter("a", q.allArtists)
            .apply {
                q.album?.let { addQueryParameter("al", it) }
                q.durationSec?.let { addQueryParameter("d", it.toString()) }
            }
            .build()
        val request = Request.Builder().url(url)
            .header("Accept", "application/json")
            .header("User-Agent", USER_AGENT)
            .build()

        return when (val r = http.fetchText(request)) {
            is HttpResult.Ok -> parseBody(r.body)?.let { Outcome.Hit(it) } ?: Outcome.Miss("malformed response")
            is HttpResult.Status -> Outcome.Miss(
                when (r.code) {
                    401 -> "not cached and no API key"
                    404 -> "no lyrics for this track"
                    429 -> "rate limited (Retry-After=${r.retryAfter})"
                    else -> "HTTP ${r.code}"
                },
            )
            is HttpResult.Failed -> Outcome.Miss(r.reason)
        }
    }

    companion object {
        /** Expects {"ttml": "<tt ...>", "score": 0.97}. Returns null for anything else. */
        fun parseBody(body: String): Response? = try {
            val obj = Json.parseToJsonElement(body).jsonObject
            val ttml = obj["ttml"]?.jsonPrimitive?.contentOrNull
            if (ttml.isNullOrBlank()) null else Response(ttml, obj["score"]?.jsonPrimitive?.doubleOrNull)
        } catch (e: IllegalArgumentException) {
            null // includes kotlinx.serialization's decoding exceptions
        }
    }
}
