#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORK="${GITHUB_WORKSPACE:-$(pwd)}"
TEMPLATE_DIR="$WORK/template"
OUT_DIR="$WORK/out"
LOG_DIR="$WORK/logs"
mkdir -p "$OUT_DIR" "$LOG_DIR"

log() { printf '[build] %s\n' "$*"; }
fail() { printf '[build] ERROR: %s\n' "$*" >&2; exit 1; }

: "${OWNER:?OWNER must be set to the GitHub repository owner}"
: "${REPO:?REPO must be set to owner/repository}"

command -v git >/dev/null || fail 'git is required'
command -v java >/dev/null || fail 'Java is required'

log 'Cloning official Echo extension template'
rm -rf "$TEMPLATE_DIR"
git clone --depth 1 https://github.com/brahmkshatriya/echo-extension-template.git "$TEMPLATE_DIR" 2>&1 | tee "$LOG_DIR/template-clone.log"

[[ -f "$TEMPLATE_DIR/gradlew" ]] || fail 'Official template did not contain gradlew at its root'
[[ -d "$TEMPLATE_DIR/ext/src/main/java" ]] || fail 'Official template layout changed: ext/src/main/java is missing'

log 'Overlaying extension source files'
cp "$ROOT/gradle.properties" "$TEMPLATE_DIR/gradle.properties"
mkdir -p "$TEMPLATE_DIR/ext/src/main/java/dev/brahmkshatriya/echo/extension" "$TEMPLATE_DIR/ext/src/test/java/dev/brahmkshatriya/echo/extension"
cp -R "$ROOT/ext/src/main/java/dev/brahmkshatriya/echo/extension/." "$TEMPLATE_DIR/ext/src/main/java/dev/brahmkshatriya/echo/extension/"
cp -R "$ROOT/ext/src/test/java/dev/brahmkshatriya/echo/extension/." "$TEMPLATE_DIR/ext/src/test/java/dev/brahmkshatriya/echo/extension/"
rm -f "$TEMPLATE_DIR/ext/src/main/java/dev/brahmkshatriya/echo/extension/TestExtension.kt" \
      "$TEMPLATE_DIR/ext/src/main/java/dev/brahmkshatriya/echo/extension/ExampleExtension.kt"

log 'Filling extension metadata'
python3 - "$TEMPLATE_DIR/gradle.properties" "$OWNER" "https://github.com/$REPO" <<'PY'
import pathlib, sys
p = pathlib.Path(sys.argv[1])
owner, repo_url = sys.argv[2], sys.argv[3]
s = p.read_text()
replacements = {
    'extAuthor=Your Name': f'extAuthor={owner}',
    'extAuthorUrl=': f'extAuthorUrl=https://github.com/{owner}',
    'extRepoUrl=': f'extRepoUrl={repo_url}',
    'extUpdateUrl=': f'extUpdateUrl={repo_url}/releases/latest',
}
for old, new in replacements.items():
    if old in s:
        s = s.replace(old, new, 1)
# Validate actual property values, not just the absence of the literal placeholder.
props = {}
for line in s.splitlines():
    if '=' in line and not line.lstrip().startswith('#'):
        k, v = line.split('=', 1); props[k.strip()] = v.strip()
for key in ('extAuthor', 'extAuthorUrl', 'extRepoUrl'):
    if not props.get(key) or 'Your Name' in props[key]:
        raise SystemExit(f'Missing or placeholder metadata: {key}')
p.write_text(s)
PY

BUILD_FILE="$TEMPLATE_DIR/ext/build.gradle.kts"
[[ -f "$BUILD_FILE" ]] || fail 'Template layout changed: ext/build.gradle.kts is missing'

log 'Ensuring required dependencies are present'
python3 - "$BUILD_FILE" <<'PY'
import pathlib, sys
p = pathlib.Path(sys.argv[1])
s = p.read_text()
block = '''\n// Dependencies required by Better Lyrics extension (safe if this script is rerun).\ndependencies {\n    implementation("com.squareup.okhttp3:okhttp:4.12.0")\n    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")\n    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.9.0")\n    testImplementation("junit:junit:4.13.2")\n}\n'''
if 'BETTER_LYRICS_BUILD_DEPENDENCIES' not in s:
    block = block.replace('// Dependencies required by Better Lyrics extension (safe if this script is rerun).', '// BETTER_LYRICS_BUILD_DEPENDENCIES\n// Dependencies required by Better Lyrics extension (safe if this script is rerun).')
    s += '\n' + block
p.write_text(s)
PY

cd "$TEMPLATE_DIR"
chmod +x ./gradlew
log 'Building debug APK'
set +e
./gradlew --no-daemon :app:assembleDebug 2>&1 | tee "$LOG_DIR/assembleDebug.log"
BUILD_STATUS=${PIPESTATUS[0]}
set -e
if [[ $BUILD_STATUS -ne 0 ]]; then
  log 'APK build failed; preserving logs for diagnosis'
  exit "$BUILD_STATUS"
fi

APK="$TEMPLATE_DIR/app/build/outputs/apk/debug/app-debug.apk"
[[ -s "$APK" ]] || fail "Gradle reported success but APK was not found at $APK"
cp "$APK" "$OUT_DIR/better_lyrics.apk"
cp "$APK" "$OUT_DIR/better_lyrics.eapk"

log 'Running unit tests (a test failure does not delete the built APK)'
set +e
./gradlew --no-daemon :ext:test 2>&1 | tee "$LOG_DIR/unit-tests.log"
TEST_STATUS=${PIPESTATUS[0]}
set -e

cat > "$GITHUB_STEP_SUMMARY" <<SUMMARY
## Better Lyrics build summary

- APK build: **passed**
- Unit tests: **$([ "$TEST_STATUS" -eq 0 ] && echo passed || echo failed)**
- APK artifact: \\`better_lyrics.apk\\`
- EAPK-named copy: \\`better_lyrics.eapk\\` (same bytes as APK; import compatibility is not independently verified)

A successful build confirms compilation only. It does **not** confirm Echo loads this extension or that word-by-word highlighting works during playback.
SUMMARY

if [[ "$TEST_STATUS" -ne 0 ]]; then
  log 'Unit tests failed; APK is still available in the artifact. See logs/unit-tests.log.'
fi
